# TechFram

Smart Help Portal for Farmers.

Features: Crop Advisor, Weather, Schemes, Mandi Prices, Soil Testing, Expert Forum.
