// TechFram landing page placeholder
export default function Home(){ return <div>TechFram</div>; }
